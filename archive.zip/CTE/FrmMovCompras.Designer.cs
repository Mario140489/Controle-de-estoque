﻿namespace CTE
{
    partial class FrmMovCompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Opções = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.btcancelar = new DevComponents.DotNetBar.ButtonX();
            this.btexcluir = new DevComponents.DotNetBar.ButtonX();
            this.btsalvar = new DevComponents.DotNetBar.ButtonX();
            this.btnovo = new DevComponents.DotNetBar.ButtonX();
            this.superTabControl1 = new DevComponents.DotNetBar.SuperTabControl();
            this.superTabControlPanel2 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.buttonX3 = new DevComponents.DotNetBar.ButtonX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.txtvaloruni = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.xdas = new DevComponents.DotNetBar.LabelX();
            this.txtqut = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.Lproduto = new DevComponents.DotNetBar.LabelX();
            this.buttonX2 = new DevComponents.DotNetBar.ButtonX();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.txtcodprod = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.btlocfor = new DevComponents.DotNetBar.ButtonX();
            this.Lbforn = new DevComponents.DotNetBar.LabelX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.txtcodForn = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.dtvprodvenda = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.bt = new DevComponents.DotNetBar.LabelX();
            this.dtcompra = new DevComponents.Editors.DateTimeAdv.DateTimeInput();
            this.dateTimeInput2 = new DevComponents.Editors.DateTimeAdv.DateTimeInput();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.txtcod = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.comboBoxEx2 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.txtnf = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.textBoxX1 = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.comboBoxEx1 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.superTabItem2 = new DevComponents.DotNetBar.SuperTabItem();
            this.superTabControlPanel1 = new DevComponents.DotNetBar.SuperTabControlPanel();
            this.Consultar = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.buttonX1 = new DevComponents.DotNetBar.ButtonX();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.txtpesquisa = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.dataGridViewX1 = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.Código = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descrição = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.superTabItem1 = new DevComponents.DotNetBar.SuperTabItem();
            this.Opções.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).BeginInit();
            this.superTabControl1.SuspendLayout();
            this.superTabControlPanel2.SuspendLayout();
            this.groupPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtvprodvenda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtcompra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTimeInput2)).BeginInit();
            this.superTabControlPanel1.SuspendLayout();
            this.Consultar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewX1)).BeginInit();
            this.SuspendLayout();
            // 
            // Opções
            // 
            this.Opções.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.Opções.CanvasColor = System.Drawing.SystemColors.Control;
            this.Opções.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2013;
            this.Opções.Controls.Add(this.btcancelar);
            this.Opções.Controls.Add(this.btexcluir);
            this.Opções.Controls.Add(this.btsalvar);
            this.Opções.Controls.Add(this.btnovo);
            this.Opções.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Opções.DisabledBackColor = System.Drawing.Color.Empty;
            this.Opções.Location = new System.Drawing.Point(4, 435);
            this.Opções.Name = "Opções";
            this.Opções.Size = new System.Drawing.Size(642, 66);
            // 
            // 
            // 
            this.Opções.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.Opções.Style.BackColorGradientAngle = 90;
            this.Opções.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.Opções.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Opções.Style.BorderBottomWidth = 1;
            this.Opções.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.Opções.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Opções.Style.BorderLeftWidth = 1;
            this.Opções.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Opções.Style.BorderRightWidth = 1;
            this.Opções.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Opções.Style.BorderTopWidth = 1;
            this.Opções.Style.CornerDiameter = 4;
            this.Opções.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.Opções.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.Opções.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.Opções.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.Opções.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.Opções.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Opções.TabIndex = 6;
            this.Opções.Text = "Opções";
            // 
            // btcancelar
            // 
            this.btcancelar.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btcancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btcancelar.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btcancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btcancelar.Location = new System.Drawing.Point(335, 4);
            this.btcancelar.Name = "btcancelar";
            this.btcancelar.Size = new System.Drawing.Size(83, 38);
            this.btcancelar.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btcancelar.Symbol = "";
            this.btcancelar.TabIndex = 9;
            this.btcancelar.Text = "Cancelar";
            // 
            // btexcluir
            // 
            this.btexcluir.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btexcluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btexcluir.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btexcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btexcluir.Location = new System.Drawing.Point(449, 3);
            this.btexcluir.Name = "btexcluir";
            this.btexcluir.PopupSide = DevComponents.DotNetBar.ePopupSide.Bottom;
            this.btexcluir.Size = new System.Drawing.Size(83, 39);
            this.btexcluir.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btexcluir.Symbol = "";
            this.btexcluir.TabIndex = 8;
            this.btexcluir.Text = "Excluir";
            // 
            // btsalvar
            // 
            this.btsalvar.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btsalvar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btsalvar.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btsalvar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btsalvar.Location = new System.Drawing.Point(219, 3);
            this.btsalvar.Name = "btsalvar";
            this.btsalvar.Size = new System.Drawing.Size(83, 38);
            this.btsalvar.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btsalvar.Symbol = "";
            this.btsalvar.TabIndex = 7;
            this.btsalvar.Text = "Salvar";
            // 
            // btnovo
            // 
            this.btnovo.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnovo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnovo.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btnovo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnovo.Location = new System.Drawing.Point(107, 3);
            this.btnovo.Name = "btnovo";
            this.btnovo.Size = new System.Drawing.Size(83, 39);
            this.btnovo.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btnovo.Symbol = "";
            this.btnovo.TabIndex = 6;
            this.btnovo.Text = "Novo";
            // 
            // superTabControl1
            // 
            this.superTabControl1.BackColor = System.Drawing.Color.White;
            this.superTabControl1.BackgroundImage = global::CTE.Properties.Resources.Menu1;
            // 
            // 
            // 
            // 
            // 
            // 
            this.superTabControl1.ControlBox.CloseBox.Name = "";
            // 
            // 
            // 
            this.superTabControl1.ControlBox.MenuBox.Name = "";
            this.superTabControl1.ControlBox.Name = "";
            this.superTabControl1.ControlBox.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabControl1.ControlBox.MenuBox,
            this.superTabControl1.ControlBox.CloseBox});
            this.superTabControl1.Controls.Add(this.superTabControlPanel1);
            this.superTabControl1.Controls.Add(this.superTabControlPanel2);
            this.superTabControl1.ForeColor = System.Drawing.Color.Black;
            this.superTabControl1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.superTabControl1.Location = new System.Drawing.Point(1, 1);
            this.superTabControl1.Name = "superTabControl1";
            this.superTabControl1.ReorderTabsEnabled = true;
            this.superTabControl1.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.superTabControl1.SelectedTabIndex = 0;
            this.superTabControl1.Size = new System.Drawing.Size(649, 428);
            this.superTabControl1.TabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.superTabControl1.TabIndex = 5;
            this.superTabControl1.Tabs.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.superTabItem1,
            this.superTabItem2});
            this.superTabControl1.TabStyle = DevComponents.DotNetBar.eSuperTabStyle.Office2010BackstageBlue;
            this.superTabControl1.TabVerticalSpacing = 10;
            this.superTabControl1.Text = "superTabControl1";
            // 
            // superTabControlPanel2
            // 
            this.superTabControlPanel2.Controls.Add(this.groupPanel1);
            this.superTabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel2.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel2.Name = "superTabControlPanel2";
            this.superTabControlPanel2.Size = new System.Drawing.Size(649, 393);
            this.superTabControlPanel2.TabIndex = 0;
            this.superTabControlPanel2.TabItem = this.superTabItem2;
            // 
            // groupPanel1
            // 
            this.groupPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.labelX13);
            this.groupPanel1.Controls.Add(this.buttonX3);
            this.groupPanel1.Controls.Add(this.labelX12);
            this.groupPanel1.Controls.Add(this.txtvaloruni);
            this.groupPanel1.Controls.Add(this.xdas);
            this.groupPanel1.Controls.Add(this.txtqut);
            this.groupPanel1.Controls.Add(this.Lproduto);
            this.groupPanel1.Controls.Add(this.buttonX2);
            this.groupPanel1.Controls.Add(this.labelX11);
            this.groupPanel1.Controls.Add(this.txtcodprod);
            this.groupPanel1.Controls.Add(this.labelX5);
            this.groupPanel1.Controls.Add(this.btlocfor);
            this.groupPanel1.Controls.Add(this.Lbforn);
            this.groupPanel1.Controls.Add(this.labelX10);
            this.groupPanel1.Controls.Add(this.txtcodForn);
            this.groupPanel1.Controls.Add(this.dtvprodvenda);
            this.groupPanel1.Controls.Add(this.labelX9);
            this.groupPanel1.Controls.Add(this.bt);
            this.groupPanel1.Controls.Add(this.dtcompra);
            this.groupPanel1.Controls.Add(this.dateTimeInput2);
            this.groupPanel1.Controls.Add(this.labelX4);
            this.groupPanel1.Controls.Add(this.labelX3);
            this.groupPanel1.Controls.Add(this.labelX8);
            this.groupPanel1.Controls.Add(this.labelX7);
            this.groupPanel1.Controls.Add(this.txtcod);
            this.groupPanel1.Controls.Add(this.comboBoxEx2);
            this.groupPanel1.Controls.Add(this.txtnf);
            this.groupPanel1.Controls.Add(this.textBoxX1);
            this.groupPanel1.Controls.Add(this.comboBoxEx1);
            this.groupPanel1.Controls.Add(this.labelX6);
            this.groupPanel1.DisabledBackColor = System.Drawing.Color.Empty;
            this.groupPanel1.Location = new System.Drawing.Point(3, 3);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(639, 387);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 0;
            this.groupPanel1.Text = "Cadastro";
            // 
            // labelX13
            // 
            this.labelX13.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX13.Location = new System.Drawing.Point(5, 126);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(73, 15);
            this.labelX13.TabIndex = 37;
            this.labelX13.Text = "Itens Compra:";
            // 
            // buttonX3
            // 
            this.buttonX3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonX3.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.buttonX3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonX3.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.buttonX3.Location = new System.Drawing.Point(599, 100);
            this.buttonX3.Name = "buttonX3";
            this.buttonX3.Size = new System.Drawing.Size(26, 21);
            this.buttonX3.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.buttonX3.SubItemsExpandWidth = 8;
            this.buttonX3.Symbol = "";
            this.buttonX3.SymbolSize = 12F;
            this.buttonX3.TabIndex = 36;
            // 
            // labelX12
            // 
            this.labelX12.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX12.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX12.Location = new System.Drawing.Point(519, 72);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(90, 22);
            this.labelX12.TabIndex = 35;
            this.labelX12.Text = "Valor Unitario:";
            // 
            // txtvaloruni
            // 
            this.txtvaloruni.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtvaloruni.Border.Class = "TextBoxBorder";
            this.txtvaloruni.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtvaloruni.DisabledBackColor = System.Drawing.Color.White;
            this.txtvaloruni.ForeColor = System.Drawing.Color.Black;
            this.txtvaloruni.Location = new System.Drawing.Point(519, 100);
            this.txtvaloruni.MaxLength = 10;
            this.txtvaloruni.Name = "txtvaloruni";
            this.txtvaloruni.PreventEnterBeep = true;
            this.txtvaloruni.Size = new System.Drawing.Size(74, 20);
            this.txtvaloruni.TabIndex = 34;
            // 
            // xdas
            // 
            this.xdas.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.xdas.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.xdas.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.xdas.Location = new System.Drawing.Point(423, 71);
            this.xdas.Name = "xdas";
            this.xdas.Size = new System.Drawing.Size(90, 23);
            this.xdas.TabIndex = 33;
            this.xdas.Text = "Quantidade:";
            // 
            // txtqut
            // 
            this.txtqut.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtqut.Border.Class = "TextBoxBorder";
            this.txtqut.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtqut.DisabledBackColor = System.Drawing.Color.White;
            this.txtqut.ForeColor = System.Drawing.Color.Black;
            this.txtqut.Location = new System.Drawing.Point(423, 100);
            this.txtqut.MaxLength = 10;
            this.txtqut.Name = "txtqut";
            this.txtqut.PreventEnterBeep = true;
            this.txtqut.Size = new System.Drawing.Size(74, 20);
            this.txtqut.TabIndex = 32;
            // 
            // Lproduto
            // 
            this.Lproduto.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.Lproduto.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Lproduto.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.Lproduto.Location = new System.Drawing.Point(161, 71);
            this.Lproduto.Name = "Lproduto";
            this.Lproduto.Size = new System.Drawing.Size(288, 23);
            this.Lproduto.TabIndex = 31;
            this.Lproduto.Text = "Informe o código do produto ou clique em pesquisar";
            // 
            // buttonX2
            // 
            this.buttonX2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonX2.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.buttonX2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonX2.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.buttonX2.Location = new System.Drawing.Point(196, 99);
            this.buttonX2.Name = "buttonX2";
            this.buttonX2.Size = new System.Drawing.Size(80, 21);
            this.buttonX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.buttonX2.SubItemsExpandWidth = 8;
            this.buttonX2.Symbol = "59520";
            this.buttonX2.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.buttonX2.SymbolSize = 15F;
            this.buttonX2.TabIndex = 30;
            this.buttonX2.Text = "Pesquisar";
            // 
            // labelX11
            // 
            this.labelX11.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX11.Location = new System.Drawing.Point(5, 71);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(90, 23);
            this.labelX11.TabIndex = 29;
            this.labelX11.Text = "Cod. Produto:";
            // 
            // txtcodprod
            // 
            this.txtcodprod.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtcodprod.Border.Class = "TextBoxBorder";
            this.txtcodprod.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtcodprod.DisabledBackColor = System.Drawing.Color.White;
            this.txtcodprod.ForeColor = System.Drawing.Color.Black;
            this.txtcodprod.Location = new System.Drawing.Point(5, 100);
            this.txtcodprod.MaxLength = 30;
            this.txtcodprod.Name = "txtcodprod";
            this.txtcodprod.PreventEnterBeep = true;
            this.txtcodprod.Size = new System.Drawing.Size(185, 20);
            this.txtcodprod.TabIndex = 28;
            // 
            // labelX5
            // 
            this.labelX5.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX5.Location = new System.Drawing.Point(5, 61);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(631, 16);
            this.labelX5.TabIndex = 27;
            this.labelX5.Text = "---------------------------------------------------------------------------------" +
    "--------------------------------------------------------------------------------" +
    "-----------------";
            // 
            // btlocfor
            // 
            this.btlocfor.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btlocfor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btlocfor.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.btlocfor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btlocfor.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.btlocfor.Location = new System.Drawing.Point(196, 32);
            this.btlocfor.Name = "btlocfor";
            this.btlocfor.Size = new System.Drawing.Size(80, 21);
            this.btlocfor.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.btlocfor.SubItemsExpandWidth = 8;
            this.btlocfor.Symbol = "59520";
            this.btlocfor.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.btlocfor.SymbolSize = 15F;
            this.btlocfor.TabIndex = 26;
            this.btlocfor.Text = "Pesquisar";
            this.btlocfor.Click += new System.EventHandler(this.btlocfor_Click);
            // 
            // Lbforn
            // 
            this.Lbforn.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.Lbforn.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Lbforn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.Lbforn.Location = new System.Drawing.Point(291, 32);
            this.Lbforn.Name = "Lbforn";
            this.Lbforn.Size = new System.Drawing.Size(279, 23);
            this.Lbforn.TabIndex = 25;
            this.Lbforn.Text = "Informe o código do fornecedor ou clique em pesquisar";
            // 
            // labelX10
            // 
            this.labelX10.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX10.Location = new System.Drawing.Point(3, 32);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(101, 23);
            this.labelX10.TabIndex = 24;
            this.labelX10.Text = "Cod. Fornecedor:";
            this.labelX10.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // txtcodForn
            // 
            this.txtcodForn.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtcodForn.Border.Class = "TextBoxBorder";
            this.txtcodForn.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtcodForn.DisabledBackColor = System.Drawing.Color.White;
            this.txtcodForn.ForeColor = System.Drawing.Color.Black;
            this.txtcodForn.Location = new System.Drawing.Point(110, 32);
            this.txtcodForn.MaxLength = 20;
            this.txtcodForn.Name = "txtcodForn";
            this.txtcodForn.PreventEnterBeep = true;
            this.txtcodForn.Size = new System.Drawing.Size(80, 20);
            this.txtcodForn.TabIndex = 23;
            // 
            // dtvprodvenda
            // 
            this.dtvprodvenda.AllowUserToAddRows = false;
            this.dtvprodvenda.AllowUserToDeleteRows = false;
            this.dtvprodvenda.AllowUserToOrderColumns = true;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.dtvprodvenda.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dtvprodvenda.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.dtvprodvenda.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtvprodvenda.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dtvprodvenda.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtvprodvenda.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dtvprodvenda.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtvprodvenda.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtvprodvenda.DefaultCellStyle = dataGridViewCellStyle8;
            this.dtvprodvenda.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dtvprodvenda.EnableHeadersVisualStyles = false;
            this.dtvprodvenda.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(157)))));
            this.dtvprodvenda.Location = new System.Drawing.Point(3, 147);
            this.dtvprodvenda.Name = "dtvprodvenda";
            this.dtvprodvenda.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtvprodvenda.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            this.dtvprodvenda.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dtvprodvenda.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtvprodvenda.Size = new System.Drawing.Size(628, 169);
            this.dtvprodvenda.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "tpa_cod";
            this.dataGridViewTextBoxColumn1.HeaderText = "Código";
            this.dataGridViewTextBoxColumn1.MaxInputLength = 15;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 80;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "tpa_nome";
            this.dataGridViewTextBoxColumn2.HeaderText = "Descrição";
            this.dataGridViewTextBoxColumn2.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 305;
            // 
            // labelX9
            // 
            this.labelX9.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX9.Location = new System.Drawing.Point(376, 322);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(73, 23);
            this.labelX9.TabIndex = 21;
            this.labelX9.Text = "Dt. inical Pg:";
            // 
            // bt
            // 
            this.bt.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.bt.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.bt.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.bt.Location = new System.Drawing.Point(384, 3);
            this.bt.Name = "bt";
            this.bt.Size = new System.Drawing.Size(98, 23);
            this.bt.TabIndex = 13;
            this.bt.Text = "Data da Compra:";
            this.bt.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // dtcompra
            // 
            // 
            // 
            // 
            this.dtcompra.BackgroundStyle.Class = "DateTimeInputBackground";
            this.dtcompra.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dtcompra.ButtonDropDown.Shortcut = DevComponents.DotNetBar.eShortcut.AltDown;
            this.dtcompra.ButtonDropDown.Visible = true;
            this.dtcompra.IsPopupCalendarOpen = false;
            this.dtcompra.Location = new System.Drawing.Point(488, 6);
            // 
            // 
            // 
            // 
            // 
            // 
            this.dtcompra.MonthCalendar.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dtcompra.MonthCalendar.CalendarDimensions = new System.Drawing.Size(1, 1);
            this.dtcompra.MonthCalendar.ClearButtonVisible = true;
            // 
            // 
            // 
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.BackColorGradientAngle = 90;
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.BorderTopColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.BorderTopWidth = 1;
            this.dtcompra.MonthCalendar.CommandsBackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dtcompra.MonthCalendar.DisplayMonth = new System.DateTime(2016, 5, 1, 0, 0, 0, 0);
            // 
            // 
            // 
            this.dtcompra.MonthCalendar.NavigationBackgroundStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.dtcompra.MonthCalendar.NavigationBackgroundStyle.BackColorGradientAngle = 90;
            this.dtcompra.MonthCalendar.NavigationBackgroundStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.dtcompra.MonthCalendar.NavigationBackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dtcompra.MonthCalendar.TodayButtonVisible = true;
            this.dtcompra.Name = "dtcompra";
            this.dtcompra.Size = new System.Drawing.Size(90, 20);
            this.dtcompra.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.dtcompra.TabIndex = 12;
            this.dtcompra.Value = new System.DateTime(2016, 5, 9, 9, 11, 31, 0);
            // 
            // dateTimeInput2
            // 
            // 
            // 
            // 
            this.dateTimeInput2.BackgroundStyle.Class = "DateTimeInputBackground";
            this.dateTimeInput2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dateTimeInput2.ButtonDropDown.Shortcut = DevComponents.DotNetBar.eShortcut.AltDown;
            this.dateTimeInput2.ButtonDropDown.Visible = true;
            this.dateTimeInput2.IsPopupCalendarOpen = false;
            this.dateTimeInput2.Location = new System.Drawing.Point(376, 345);
            // 
            // 
            // 
            // 
            // 
            // 
            this.dateTimeInput2.MonthCalendar.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dateTimeInput2.MonthCalendar.CalendarDimensions = new System.Drawing.Size(1, 1);
            this.dateTimeInput2.MonthCalendar.ClearButtonVisible = true;
            // 
            // 
            // 
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.BackColorGradientAngle = 90;
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.BorderTopColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarDockedBorder;
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.BorderTopWidth = 1;
            this.dateTimeInput2.MonthCalendar.CommandsBackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dateTimeInput2.MonthCalendar.DisplayMonth = new System.DateTime(2016, 5, 1, 0, 0, 0, 0);
            // 
            // 
            // 
            this.dateTimeInput2.MonthCalendar.NavigationBackgroundStyle.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.dateTimeInput2.MonthCalendar.NavigationBackgroundStyle.BackColorGradientAngle = 90;
            this.dateTimeInput2.MonthCalendar.NavigationBackgroundStyle.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.dateTimeInput2.MonthCalendar.NavigationBackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.dateTimeInput2.MonthCalendar.TodayButtonVisible = true;
            this.dateTimeInput2.Name = "dateTimeInput2";
            this.dateTimeInput2.Size = new System.Drawing.Size(101, 20);
            this.dateTimeInput2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.dateTimeInput2.TabIndex = 20;
            this.dateTimeInput2.Value = new System.DateTime(2016, 5, 9, 9, 11, 26, 0);
            // 
            // labelX4
            // 
            this.labelX4.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Location = new System.Drawing.Point(64, 3);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(40, 23);
            this.labelX4.TabIndex = 11;
            this.labelX4.Text = "Código:";
            // 
            // labelX3
            // 
            this.labelX3.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX3.Location = new System.Drawing.Point(210, 3);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(66, 23);
            this.labelX3.TabIndex = 10;
            this.labelX3.Text = "Nota fiscal:";
            this.labelX3.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // labelX8
            // 
            this.labelX8.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX8.Location = new System.Drawing.Point(-12, 319);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(116, 23);
            this.labelX8.TabIndex = 19;
            this.labelX8.Text = "Tipo de pagamento:";
            this.labelX8.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // labelX7
            // 
            this.labelX7.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX7.Location = new System.Drawing.Point(196, 322);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(48, 23);
            this.labelX7.TabIndex = 17;
            this.labelX7.Text = "Parcelas:";
            this.labelX7.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // txtcod
            // 
            this.txtcod.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtcod.Border.Class = "TextBoxBorder";
            this.txtcod.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtcod.DisabledBackColor = System.Drawing.Color.White;
            this.txtcod.Enabled = false;
            this.txtcod.ForeColor = System.Drawing.Color.Black;
            this.txtcod.Location = new System.Drawing.Point(110, 6);
            this.txtcod.MaxLength = 20;
            this.txtcod.Name = "txtcod";
            this.txtcod.PreventEnterBeep = true;
            this.txtcod.Size = new System.Drawing.Size(80, 20);
            this.txtcod.TabIndex = 9;
            // 
            // comboBoxEx2
            // 
            this.comboBoxEx2.DisplayMember = "Text";
            this.comboBoxEx2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx2.ForeColor = System.Drawing.Color.Black;
            this.comboBoxEx2.FormattingEnabled = true;
            this.comboBoxEx2.ItemHeight = 14;
            this.comboBoxEx2.Location = new System.Drawing.Point(5, 345);
            this.comboBoxEx2.Name = "comboBoxEx2";
            this.comboBoxEx2.Size = new System.Drawing.Size(123, 20);
            this.comboBoxEx2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx2.TabIndex = 18;
            // 
            // txtnf
            // 
            this.txtnf.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtnf.Border.Class = "TextBoxBorder";
            this.txtnf.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtnf.DisabledBackColor = System.Drawing.Color.White;
            this.txtnf.ForeColor = System.Drawing.Color.Black;
            this.txtnf.Location = new System.Drawing.Point(286, 6);
            this.txtnf.MaxLength = 20;
            this.txtnf.Name = "txtnf";
            this.txtnf.PreventEnterBeep = true;
            this.txtnf.Size = new System.Drawing.Size(92, 20);
            this.txtnf.TabIndex = 8;
            // 
            // textBoxX1
            // 
            this.textBoxX1.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.textBoxX1.Border.Class = "TextBoxBorder";
            this.textBoxX1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.textBoxX1.DisabledBackColor = System.Drawing.Color.White;
            this.textBoxX1.ForeColor = System.Drawing.Color.Black;
            this.textBoxX1.Location = new System.Drawing.Point(525, 345);
            this.textBoxX1.MaxLength = 30;
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.PreventEnterBeep = true;
            this.textBoxX1.Size = new System.Drawing.Size(84, 20);
            this.textBoxX1.TabIndex = 14;
            // 
            // comboBoxEx1
            // 
            this.comboBoxEx1.DisplayMember = "Text";
            this.comboBoxEx1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx1.ForeColor = System.Drawing.Color.Black;
            this.comboBoxEx1.FormattingEnabled = true;
            this.comboBoxEx1.ItemHeight = 14;
            this.comboBoxEx1.Location = new System.Drawing.Point(196, 345);
            this.comboBoxEx1.Name = "comboBoxEx1";
            this.comboBoxEx1.Size = new System.Drawing.Size(123, 20);
            this.comboBoxEx1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.comboBoxEx1.TabIndex = 16;
            // 
            // labelX6
            // 
            this.labelX6.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.ImagePosition = DevComponents.DotNetBar.eImagePosition.Bottom;
            this.labelX6.Location = new System.Drawing.Point(525, 322);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(35, 23);
            this.labelX6.TabIndex = 15;
            this.labelX6.Text = "Total:";
            // 
            // superTabItem2
            // 
            this.superTabItem2.AttachedControl = this.superTabControlPanel2;
            this.superTabItem2.GlobalItem = false;
            this.superTabItem2.Name = "superTabItem2";
            this.superTabItem2.Text = "Editar";
            // 
            // superTabControlPanel1
            // 
            this.superTabControlPanel1.Controls.Add(this.Consultar);
            this.superTabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.superTabControlPanel1.Location = new System.Drawing.Point(0, 35);
            this.superTabControlPanel1.Name = "superTabControlPanel1";
            this.superTabControlPanel1.Size = new System.Drawing.Size(649, 393);
            this.superTabControlPanel1.TabIndex = 1;
            this.superTabControlPanel1.TabItem = this.superTabItem1;
            // 
            // Consultar
            // 
            this.Consultar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.Consultar.CanvasColor = System.Drawing.SystemColors.Control;
            this.Consultar.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.Consultar.Controls.Add(this.buttonX1);
            this.Consultar.Controls.Add(this.labelX2);
            this.Consultar.Controls.Add(this.labelX1);
            this.Consultar.Controls.Add(this.txtpesquisa);
            this.Consultar.Controls.Add(this.dataGridViewX1);
            this.Consultar.DisabledBackColor = System.Drawing.Color.Empty;
            this.Consultar.Location = new System.Drawing.Point(3, 3);
            this.Consultar.Name = "Consultar";
            this.Consultar.Size = new System.Drawing.Size(642, 387);
            // 
            // 
            // 
            this.Consultar.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.Consultar.Style.BackColorGradientAngle = 90;
            this.Consultar.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.Consultar.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Consultar.Style.BorderBottomWidth = 1;
            this.Consultar.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.Consultar.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Consultar.Style.BorderLeftWidth = 1;
            this.Consultar.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Consultar.Style.BorderRightWidth = 1;
            this.Consultar.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.Consultar.Style.BorderTopWidth = 1;
            this.Consultar.Style.CornerDiameter = 4;
            this.Consultar.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.Consultar.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.Consultar.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.Consultar.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.Consultar.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.Consultar.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Consultar.TabIndex = 0;
            this.Consultar.Text = "Consultar";
            this.Consultar.TitleImagePosition = DevComponents.DotNetBar.eTitleImagePosition.Right;
            // 
            // buttonX1
            // 
            this.buttonX1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.buttonX1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonX1.ColorTable = DevComponents.DotNetBar.eButtonColor.BlueOrb;
            this.buttonX1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonX1.ImagePosition = DevComponents.DotNetBar.eImagePosition.Right;
            this.buttonX1.Location = new System.Drawing.Point(338, 27);
            this.buttonX1.Name = "buttonX1";
            this.buttonX1.Size = new System.Drawing.Size(80, 21);
            this.buttonX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.buttonX1.SubItemsExpandWidth = 8;
            this.buttonX1.Symbol = "59520";
            this.buttonX1.SymbolSet = DevComponents.DotNetBar.eSymbolSet.Material;
            this.buttonX1.SymbolSize = 15F;
            this.buttonX1.TabIndex = 10;
            this.buttonX1.Text = "Pesquisar";
            // 
            // labelX2
            // 
            this.labelX2.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(71, 10);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(51, 11);
            this.labelX2.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2010;
            this.labelX2.TabIndex = 9;
            this.labelX2.Text = "Descrição";
            this.labelX2.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // labelX1
            // 
            this.labelX1.BackColor = System.Drawing.Color.Transparent;
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.ImeMode = System.Windows.Forms.ImeMode.On;
            this.labelX1.Location = new System.Drawing.Point(3, 24);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(62, 23);
            this.labelX1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.labelX1.TabIndex = 8;
            this.labelX1.Text = "Pesquisar:";
            this.labelX1.TextAlignment = System.Drawing.StringAlignment.Far;
            // 
            // txtpesquisa
            // 
            this.txtpesquisa.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtpesquisa.Border.Class = "TextBoxBorder";
            this.txtpesquisa.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.txtpesquisa.DisabledBackColor = System.Drawing.Color.White;
            this.txtpesquisa.ForeColor = System.Drawing.Color.Black;
            this.txtpesquisa.Location = new System.Drawing.Point(71, 27);
            this.txtpesquisa.MaxLength = 30;
            this.txtpesquisa.Name = "txtpesquisa";
            this.txtpesquisa.PreventEnterBeep = true;
            this.txtpesquisa.Size = new System.Drawing.Size(261, 20);
            this.txtpesquisa.TabIndex = 7;
            // 
            // dataGridViewX1
            // 
            this.dataGridViewX1.AllowUserToAddRows = false;
            this.dataGridViewX1.AllowUserToDeleteRows = false;
            this.dataGridViewX1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            this.dataGridViewX1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewX1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            this.dataGridViewX1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewX1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridViewX1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewX1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewX1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewX1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Código,
            this.Descrição});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(242)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewX1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewX1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dataGridViewX1.EnableHeadersVisualStyles = false;
            this.dataGridViewX1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(155)))), ((int)(((byte)(155)))), ((int)(((byte)(157)))));
            this.dataGridViewX1.Location = new System.Drawing.Point(3, 53);
            this.dataGridViewX1.Name = "dataGridViewX1";
            this.dataGridViewX1.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewX1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewX1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewX1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewX1.Size = new System.Drawing.Size(628, 310);
            this.dataGridViewX1.TabIndex = 6;
            // 
            // Código
            // 
            this.Código.DataPropertyName = "tpa_cod";
            this.Código.HeaderText = "Código";
            this.Código.MaxInputLength = 15;
            this.Código.Name = "Código";
            this.Código.ReadOnly = true;
            this.Código.Width = 80;
            // 
            // Descrição
            // 
            this.Descrição.DataPropertyName = "tpa_nome";
            this.Descrição.HeaderText = "Descrição";
            this.Descrição.MaxInputLength = 50;
            this.Descrição.Name = "Descrição";
            this.Descrição.ReadOnly = true;
            this.Descrição.Width = 305;
            // 
            // superTabItem1
            // 
            this.superTabItem1.AttachedControl = this.superTabControlPanel1;
            this.superTabItem1.GlobalItem = false;
            this.superTabItem1.Name = "superTabItem1";
            this.superTabItem1.Text = "Consulta";
            // 
            // FrmMovCompras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 506);
            this.Controls.Add(this.Opções);
            this.Controls.Add(this.superTabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmMovCompras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Compra";
            this.Load += new System.EventHandler(this.FrmMovCompras_Load);
            this.Opções.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.superTabControl1)).EndInit();
            this.superTabControl1.ResumeLayout(false);
            this.superTabControlPanel2.ResumeLayout(false);
            this.groupPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtvprodvenda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtcompra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateTimeInput2)).EndInit();
            this.superTabControlPanel1.ResumeLayout(false);
            this.Consultar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewX1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.Controls.GroupPanel Opções;
        public DevComponents.DotNetBar.ButtonX btcancelar;
        public DevComponents.DotNetBar.ButtonX btexcluir;
        public DevComponents.DotNetBar.ButtonX btsalvar;
        public DevComponents.DotNetBar.ButtonX btnovo;
        private DevComponents.DotNetBar.SuperTabControl superTabControl1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel1;
        private DevComponents.DotNetBar.Controls.GroupPanel Consultar;
        private DevComponents.DotNetBar.ButtonX buttonX1;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.Controls.TextBoxX txtpesquisa;
        private DevComponents.DotNetBar.Controls.DataGridViewX dataGridViewX1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Código;
        private System.Windows.Forms.DataGridViewTextBoxColumn Descrição;
        private DevComponents.DotNetBar.SuperTabItem superTabItem1;
        private DevComponents.DotNetBar.SuperTabControlPanel superTabControlPanel2;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.LabelX labelX4;
        private DevComponents.DotNetBar.LabelX labelX3;
        private DevComponents.DotNetBar.Controls.TextBoxX txtcod;
        public DevComponents.DotNetBar.Controls.TextBoxX txtnf;
        private DevComponents.DotNetBar.SuperTabItem superTabItem2;
        private DevComponents.Editors.DateTimeAdv.DateTimeInput dtcompra;
        private DevComponents.DotNetBar.LabelX labelX7;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx1;
        private DevComponents.DotNetBar.LabelX labelX6;
        public DevComponents.DotNetBar.Controls.TextBoxX textBoxX1;
        private DevComponents.DotNetBar.LabelX bt;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.Editors.DateTimeAdv.DateTimeInput dateTimeInput2;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx2;
        private DevComponents.DotNetBar.Controls.DataGridViewX dtvprodvenda;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DevComponents.DotNetBar.ButtonX btlocfor;
        private DevComponents.DotNetBar.LabelX Lbforn;
        private DevComponents.DotNetBar.LabelX labelX10;
        public DevComponents.DotNetBar.Controls.TextBoxX txtcodForn;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.LabelX labelX12;
        public DevComponents.DotNetBar.Controls.TextBoxX txtvaloruni;
        private DevComponents.DotNetBar.LabelX xdas;
        public DevComponents.DotNetBar.Controls.TextBoxX txtqut;
        private DevComponents.DotNetBar.LabelX Lproduto;
        private DevComponents.DotNetBar.ButtonX buttonX2;
        private DevComponents.DotNetBar.LabelX labelX11;
        public DevComponents.DotNetBar.Controls.TextBoxX txtcodprod;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.DotNetBar.ButtonX buttonX3;
    }
}